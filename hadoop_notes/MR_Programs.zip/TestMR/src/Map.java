

import java.io.IOException;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;

public class Map extends Mapper<LongWritable, DBInputWritable, IntWritable,Text>
{


   protected void map(LongWritable id, DBInputWritable value, Context ctx)
   {
     try
     {
    	    String line = value.getName();
    	    IntWritable cd = new IntWritable(value.getId());
      
           ctx.write(cd,new Text(line));
 
     } catch(IOException e)
     {
        e.printStackTrace();
     } catch(InterruptedException e)
     {
        e.printStackTrace();
     }
   }
}
