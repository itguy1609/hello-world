

import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapred.lib.IdentityReducer;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.db.DBConfiguration;
import org.apache.hadoop.mapreduce.lib.db.DBInputFormat;
import org.apache.hadoop.mapreduce.lib.db.DBOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;

public class MainDbtohdfs
{
   public static void main(String[] args) throws Exception
   {
	   Configuration conf = new Configuration();
	     DBConfiguration.configureDB(conf,
	     "com.mysql.jdbc.Driver",   // driver class
	     "jdbc:mysql://192.168.56.1:3306/edureka", // db url
	     "root",    // user name
	     "root"); //password

	     Job job = new Job(conf);
	     job.setJarByClass(MainDbtohdfs.class);
	     job.setMapperClass(Map.class);
	   //  job.setReducerClass(IdentityReducer.class);
	     job.setMapOutputKeyClass(IntWritable.class);
	     job.setMapOutputValueClass(Text.class);
	    // job.setOutputKeyClass(DBOutputWritable.class);
	    // job.setOutputValueClass(NullWritable.class);
	     job.setInputFormatClass(DBInputFormat.class);
	     //job.setOutputFormatClass(DBOutputFormat.class);
	     
	   
	       
	    
	     FileOutputFormat.setOutputPath(job, new Path(args[0]));
			
	     DBInputFormat.setInput(
	     job,
	     DBInputWritable.class,
	     "employee",   //input table name
	     null,
	     null,
	     new String[] { "id", "name" }  // table columns
	     );

//	     DBOutputFormat.setOutput(
//	     job,
//	     "output",    // output table name
//	     new String[] { "name", "count" }   //table columns
//	     );
	     Path p=new Path(args[0]);
	     FileSystem fs= FileSystem.get(new URI(args[0]), conf);
	     fs.delete(p);


	     System.exit(job.waitForCompletion(true) ? 0 : 1);
   }
}